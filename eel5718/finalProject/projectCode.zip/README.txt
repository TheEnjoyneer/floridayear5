# All python code for this assignment should be executed 
# simply through the following command

$ sudo python3 <name of topology python file>

# Where the names of the files will all be the topology type 
# plus Topo.py
# Ex. linearTopo.py
# Example command below

$ sudo python3 linearTopo.py

# All code should run all the metrics necessary via ping and iperf3 in the script 
# for each individual topology

